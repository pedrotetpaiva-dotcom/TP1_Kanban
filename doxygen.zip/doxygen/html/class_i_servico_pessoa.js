var class_i_servico_pessoa =
[
    [ "atualizar", "class_i_servico_pessoa.html#a9548a7f365c699843aa291cb8d0450a5", null ],
    [ "atualizar", "class_i_servico_pessoa.html#a9548a7f365c699843aa291cb8d0450a5", null ],
    [ "criar", "class_i_servico_pessoa.html#aa76114ff7aca7e8814b3ef0fbd840e26", null ],
    [ "criar", "class_i_servico_pessoa.html#aa76114ff7aca7e8814b3ef0fbd840e26", null ],
    [ "excluir", "class_i_servico_pessoa.html#a3ddd2da729bd6f3f1105c87ced5b4341", null ],
    [ "excluir", "class_i_servico_pessoa.html#a3ddd2da729bd6f3f1105c87ced5b4341", null ],
    [ "ler", "class_i_servico_pessoa.html#a372bca9f20439657c8664a4d95df3c5f", null ],
    [ "ler", "class_i_servico_pessoa.html#a372bca9f20439657c8664a4d95df3c5f", null ],
    [ "listar", "class_i_servico_pessoa.html#a3fee76234ca8a2b9c66e4f3693abbddf", null ],
    [ "listar", "class_i_servico_pessoa.html#a3fee76234ca8a2b9c66e4f3693abbddf", null ]
];