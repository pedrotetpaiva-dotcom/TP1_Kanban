var files_dup =
[
    [ "include", "dir_d44c64559bbebec7f509842c48db8b23.html", "dir_d44c64559bbebec7f509842c48db8b23" ],
    [ "TP1_Kanban", "dir_dc4f45fd0b73174d4682fa54bb6dff47.html", "dir_dc4f45fd0b73174d4682fa54bb6dff47" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ]
];