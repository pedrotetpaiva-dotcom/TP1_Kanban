var _t_p1___kanban_2include_2nome_8h =
[
    [ "Nome", "class_nome.html", "class_nome" ]
];