var _t_p1___kanban_2include_2estado_8h =
[
    [ "Estado", "class_estado.html", "class_estado" ]
];