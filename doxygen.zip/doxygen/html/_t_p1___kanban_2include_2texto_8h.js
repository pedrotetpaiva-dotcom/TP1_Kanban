var _t_p1___kanban_2include_2texto_8h =
[
    [ "Texto", "class_texto.html", "class_texto" ]
];