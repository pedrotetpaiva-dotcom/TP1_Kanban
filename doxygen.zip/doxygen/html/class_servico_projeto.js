var class_servico_projeto =
[
    [ "atualizar", "class_servico_projeto.html#a2747c2c68a3ffcf68fc8eade7a8809f1", null ],
    [ "criar", "class_servico_projeto.html#ab9cd7a5339c541799e787a9c09717cf2", null ],
    [ "excluir", "class_servico_projeto.html#ad554826f481dd71ce462a89fbe763616", null ],
    [ "ler", "class_servico_projeto.html#ace7830f63164b4657de20c76dd6a6f64", null ],
    [ "listar", "class_servico_projeto.html#af1d0c7957a372afa403bf6fb937af7ff", null ]
];