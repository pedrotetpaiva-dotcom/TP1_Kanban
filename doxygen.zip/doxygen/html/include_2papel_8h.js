var include_2papel_8h =
[
    [ "Papel", "class_papel.html", "class_papel" ]
];