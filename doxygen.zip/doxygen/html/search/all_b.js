var searchData=
[
  ['remover_0',['remover',['../class_container_cartao.html#a687bc760e402b777465909c9f066374b',1,'ContainerCartao::remover()'],['../class_container_pessoa.html#a866eacfc83cccb3dbebdf80978a9d50f',1,'ContainerPessoa::remover()'],['../class_container_projeto.html#aaa0d7172e98996b47487b4ed095dfbdc',1,'ContainerProjeto::remover()'],['../class_container_quadro.html#a62bcb9e8e055a987403acbc5f563d833',1,'ContainerQuadro::remover()']]]
];
