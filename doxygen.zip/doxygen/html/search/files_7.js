var searchData=
[
  ['quadro_2eh_0',['quadro.h',['../include_2quadro_8h.html',1,'']]]
];
