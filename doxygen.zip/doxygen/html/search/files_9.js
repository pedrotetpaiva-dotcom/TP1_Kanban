var searchData=
[
  ['tamanho_2eh_0',['tamanho.h',['../include_2tamanho_8h.html',1,'(Global Namespace)'],['../_t_p1___kanban_2include_2tamanho_8h.html',1,'(Global Namespace)']]],
  ['texto_2eh_1',['texto.h',['../include_2texto_8h.html',1,'(Global Namespace)'],['../_t_p1___kanban_2include_2texto_8h.html',1,'(Global Namespace)']]],
  ['timestamp_2eh_2',['timestamp.h',['../include_2timestamp_8h.html',1,'(Global Namespace)'],['../_t_p1___kanban_2include_2timestamp_8h.html',1,'(Global Namespace)']]]
];
