var searchData=
[
  ['nome_2eh_0',['nome.h',['../include_2nome_8h.html',1,'(Global Namespace)'],['../_t_p1___kanban_2include_2nome_8h.html',1,'(Global Namespace)']]]
];
