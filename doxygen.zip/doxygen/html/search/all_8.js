var searchData=
[
  ['nome_0',['Nome',['../class_nome.html',1,'']]],
  ['nome_2eh_1',['nome.h',['../include_2nome_8h.html',1,'(Global Namespace)'],['../_t_p1___kanban_2include_2nome_8h.html',1,'(Global Namespace)']]]
];
