var searchData=
[
  ['tamanho_0',['Tamanho',['../class_tamanho.html',1,'']]],
  ['tamanho_2eh_1',['tamanho.h',['../include_2tamanho_8h.html',1,'(Global Namespace)'],['../_t_p1___kanban_2include_2tamanho_8h.html',1,'(Global Namespace)']]],
  ['texto_2',['Texto',['../class_texto.html',1,'']]],
  ['texto_2eh_3',['texto.h',['../include_2texto_8h.html',1,'(Global Namespace)'],['../_t_p1___kanban_2include_2texto_8h.html',1,'(Global Namespace)']]],
  ['timestamp_4',['Timestamp',['../class_timestamp.html',1,'']]],
  ['timestamp_2eh_5',['timestamp.h',['../include_2timestamp_8h.html',1,'(Global Namespace)'],['../_t_p1___kanban_2include_2timestamp_8h.html',1,'(Global Namespace)']]]
];
