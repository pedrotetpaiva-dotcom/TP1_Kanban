var class_i_servico_projeto =
[
    [ "atualizar", "class_i_servico_projeto.html#a29ce48ab730d9864244802a1a3143dce", null ],
    [ "atualizar", "class_i_servico_projeto.html#a29ce48ab730d9864244802a1a3143dce", null ],
    [ "criar", "class_i_servico_projeto.html#a80462633a55d5282faee998915e49359", null ],
    [ "criar", "class_i_servico_projeto.html#a80462633a55d5282faee998915e49359", null ],
    [ "excluir", "class_i_servico_projeto.html#a060f0c2783e19e9d25ffdaa87fd67780", null ],
    [ "excluir", "class_i_servico_projeto.html#a060f0c2783e19e9d25ffdaa87fd67780", null ],
    [ "ler", "class_i_servico_projeto.html#ab9060a8c21420234db40355b3bce018f", null ],
    [ "ler", "class_i_servico_projeto.html#ab9060a8c21420234db40355b3bce018f", null ],
    [ "listar", "class_i_servico_projeto.html#af9676aeff7b9b5435f025471898858d1", null ],
    [ "listar", "class_i_servico_projeto.html#af9676aeff7b9b5435f025471898858d1", null ]
];