var class_ctrl_apresentacao_quadro =
[
    [ "CtrlApresentacaoQuadro", "class_ctrl_apresentacao_quadro.html#a014e4becb43d8af7f54dc70288d2097f", null ],
    [ "CtrlApresentacaoQuadro", "class_ctrl_apresentacao_quadro.html#a014e4becb43d8af7f54dc70288d2097f", null ],
    [ "executarMenu", "class_ctrl_apresentacao_quadro.html#ab4ef4634982d9e545d73a7cc1f8a3d78", null ],
    [ "executarMenu", "class_ctrl_apresentacao_quadro.html#ab4ef4634982d9e545d73a7cc1f8a3d78", null ],
    [ "setServico", "class_ctrl_apresentacao_quadro.html#af1239649a0fa1410e75c508198a20b9d", null ],
    [ "setServico", "class_ctrl_apresentacao_quadro.html#af1239649a0fa1410e75c508198a20b9d", null ],
    [ "setUsuario", "class_ctrl_apresentacao_quadro.html#a0413c6f0ace1c8aa32576d045c44e5bd", null ],
    [ "setUsuario", "class_ctrl_apresentacao_quadro.html#a0413c6f0ace1c8aa32576d045c44e5bd", null ]
];