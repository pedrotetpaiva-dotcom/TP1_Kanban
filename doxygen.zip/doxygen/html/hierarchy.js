var hierarchy =
[
    [ "BancoDados", "class_banco_dados.html", null ],
    [ "CartaoAtividade", "class_cartao_atividade.html", null ],
    [ "ContainerCartao", "class_container_cartao.html", null ],
    [ "ContainerPessoa", "class_container_pessoa.html", null ],
    [ "ContainerProjeto", "class_container_projeto.html", null ],
    [ "ContainerQuadro", "class_container_quadro.html", null ],
    [ "CtrlApresentacaoAutenticacao", "class_ctrl_apresentacao_autenticacao.html", null ],
    [ "CtrlApresentacaoCartao", "class_ctrl_apresentacao_cartao.html", null ],
    [ "CtrlApresentacaoPrincipal", "class_ctrl_apresentacao_principal.html", null ],
    [ "CtrlApresentacaoProjeto", "class_ctrl_apresentacao_projeto.html", null ],
    [ "CtrlApresentacaoQuadro", "class_ctrl_apresentacao_quadro.html", null ],
    [ "Email", "class_email.html", null ],
    [ "Estado", "class_estado.html", null ],
    [ "Identificador", "class_identificador.html", null ],
    [ "IServicoAutenticacao", "class_i_servico_autenticacao.html", [
      [ "CtrlServicoAutenticacao", "class_ctrl_servico_autenticacao.html", null ],
      [ "ServicoAutenticacao", "class_servico_autenticacao.html", null ]
    ] ],
    [ "IServicoCartao", "class_i_servico_cartao.html", [
      [ "CtrlServicoCartao", "class_ctrl_servico_cartao.html", null ],
      [ "ServicoCartao", "class_servico_cartao.html", null ]
    ] ],
    [ "IServicoPessoa", "class_i_servico_pessoa.html", [
      [ "CtrlServicoPessoa", "class_ctrl_servico_pessoa.html", null ],
      [ "ServicoPessoa", "class_servico_pessoa.html", null ]
    ] ],
    [ "IServicoProjeto", "class_i_servico_projeto.html", [
      [ "CtrlServicoProjeto", "class_ctrl_servico_projeto.html", null ],
      [ "ServicoProjeto", "class_servico_projeto.html", null ]
    ] ],
    [ "IServicoQuadro", "class_i_servico_quadro.html", [
      [ "CtrlServicoQuadro", "class_ctrl_servico_quadro.html", null ],
      [ "ServicoQuadro", "class_servico_quadro.html", null ]
    ] ],
    [ "Limite", "class_limite.html", null ],
    [ "Nome", "class_nome.html", null ],
    [ "Papel", "class_papel.html", null ],
    [ "Pessoa", "class_pessoa.html", null ],
    [ "Prioridade", "class_prioridade.html", null ],
    [ "Projeto", "class_projeto.html", null ],
    [ "Quadro", "class_quadro.html", null ],
    [ "Senha", "class_senha.html", null ],
    [ "Tamanho", "class_tamanho.html", null ],
    [ "Texto", "class_texto.html", null ],
    [ "Timestamp", "class_timestamp.html", null ]
];