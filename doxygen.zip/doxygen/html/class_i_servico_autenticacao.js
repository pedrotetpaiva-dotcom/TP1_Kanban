var class_i_servico_autenticacao =
[
    [ "~IServicoAutenticacao", "class_i_servico_autenticacao.html#aa2f9ad33148b3b12a205e992079e4368", null ],
    [ "~IServicoAutenticacao", "class_i_servico_autenticacao.html#aa2f9ad33148b3b12a205e992079e4368", null ],
    [ "autenticar", "class_i_servico_autenticacao.html#a4ced028dbd2064bf02dea267315fcc95", null ],
    [ "autenticar", "class_i_servico_autenticacao.html#a4ced028dbd2064bf02dea267315fcc95", null ]
];