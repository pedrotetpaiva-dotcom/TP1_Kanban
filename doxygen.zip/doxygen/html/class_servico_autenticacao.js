var class_servico_autenticacao =
[
    [ "autenticar", "class_servico_autenticacao.html#ad30dc9425c73d8707797bfc5e3318517", null ]
];