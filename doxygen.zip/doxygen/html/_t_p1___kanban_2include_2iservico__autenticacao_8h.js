var _t_p1___kanban_2include_2iservico__autenticacao_8h =
[
    [ "IServicoAutenticacao", "class_i_servico_autenticacao.html", "class_i_servico_autenticacao" ]
];