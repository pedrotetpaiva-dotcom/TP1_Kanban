var class_ctrl_servico_projeto =
[
    [ "CtrlServicoProjeto", "class_ctrl_servico_projeto.html#a9e9e5fd817eb3398e461c67d14587273", null ],
    [ "atualizar", "class_ctrl_servico_projeto.html#a8af1ac7b2b2756252dc5ae3b18f0bebd", null ],
    [ "criar", "class_ctrl_servico_projeto.html#ac675bb6a1a59177dfb95c540f955471b", null ],
    [ "excluir", "class_ctrl_servico_projeto.html#a79017817df4aec2a108466ee97183423", null ],
    [ "ler", "class_ctrl_servico_projeto.html#a7f8810ed9d18b77d7144ccae191789a8", null ],
    [ "listar", "class_ctrl_servico_projeto.html#ad4dfb1a0c8dda5a118b2fe8d152bf2cc", null ]
];