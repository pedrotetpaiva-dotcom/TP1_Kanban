var class_ctrl_servico_pessoa =
[
    [ "CtrlServicoPessoa", "class_ctrl_servico_pessoa.html#a4eaa2d3ffd02156c5cc3bb5f6fef461c", null ],
    [ "atualizar", "class_ctrl_servico_pessoa.html#af7650b6ec1fcb1e724810a3c66851cbf", null ],
    [ "criar", "class_ctrl_servico_pessoa.html#a83cc86ae654bfc5ed1c9ff952d538cbd", null ],
    [ "excluir", "class_ctrl_servico_pessoa.html#a81a60ef38dd5c7af1ee4e5b04abff206", null ],
    [ "ler", "class_ctrl_servico_pessoa.html#a5e928f3a2c4ec0b1ffe883f256f62e07", null ],
    [ "listar", "class_ctrl_servico_pessoa.html#ae4131e38af342c5d22a62c2e57387792", null ]
];