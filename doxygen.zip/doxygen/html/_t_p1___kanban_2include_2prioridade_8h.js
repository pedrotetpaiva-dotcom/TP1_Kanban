var _t_p1___kanban_2include_2prioridade_8h =
[
    [ "Prioridade", "class_prioridade.html", "class_prioridade" ]
];