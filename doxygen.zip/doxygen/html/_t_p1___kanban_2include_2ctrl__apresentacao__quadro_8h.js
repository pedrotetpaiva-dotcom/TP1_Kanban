var _t_p1___kanban_2include_2ctrl__apresentacao__quadro_8h =
[
    [ "CtrlApresentacaoQuadro", "class_ctrl_apresentacao_quadro.html", "class_ctrl_apresentacao_quadro" ]
];