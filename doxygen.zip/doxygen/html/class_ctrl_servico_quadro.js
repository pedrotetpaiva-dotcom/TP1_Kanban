var class_ctrl_servico_quadro =
[
    [ "CtrlServicoQuadro", "class_ctrl_servico_quadro.html#a666fb6de9464e1f997285de9e76c0c79", null ],
    [ "atualizar", "class_ctrl_servico_quadro.html#a84f78249bb33336e063d664ffa8d5d55", null ],
    [ "criar", "class_ctrl_servico_quadro.html#a71d17b0df151d367dbf66c6eb9e42e11", null ],
    [ "excluir", "class_ctrl_servico_quadro.html#abf8e4c17a2c37175b77cfe6df17abacd", null ],
    [ "ler", "class_ctrl_servico_quadro.html#a4c94ff960f1ade6b2dc0a590544ab36e", null ],
    [ "listar", "class_ctrl_servico_quadro.html#a60d966593b6d67f9ee1728bda11a1559", null ]
];