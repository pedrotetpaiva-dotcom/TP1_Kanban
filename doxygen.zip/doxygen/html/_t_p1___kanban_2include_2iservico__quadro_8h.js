var _t_p1___kanban_2include_2iservico__quadro_8h =
[
    [ "IServicoQuadro", "class_i_servico_quadro.html", "class_i_servico_quadro" ]
];