var class_servico_quadro =
[
    [ "atualizar", "class_servico_quadro.html#ae69f3a33199abed1bb757b4974008d8c", null ],
    [ "criar", "class_servico_quadro.html#afd3e34e166f494114c4d28cb18e8bb41", null ],
    [ "excluir", "class_servico_quadro.html#a1cf4a3b4b672cce4c9b4515ff269859a", null ],
    [ "ler", "class_servico_quadro.html#afd6ff941fd4e4128c0a16c40c6ddc76b", null ],
    [ "listar", "class_servico_quadro.html#a28257171b00d0960b2019cece6c9ba0f", null ]
];