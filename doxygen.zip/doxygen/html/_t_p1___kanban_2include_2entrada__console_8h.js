var _t_p1___kanban_2include_2entrada__console_8h =
[
    [ "lerLinha", "_t_p1___kanban_2include_2entrada__console_8h.html#a6d20e8b2df78246cc8bb8204fe35f4b9", null ],
    [ "lerOpcao", "_t_p1___kanban_2include_2entrada__console_8h.html#adc58f27faa4428f5043e459afb07f1bf", null ],
    [ "lerPalavra", "_t_p1___kanban_2include_2entrada__console_8h.html#a08fff5e0db87d58e4f0408ffeba8d47d", null ],
    [ "pedirLinha", "_t_p1___kanban_2include_2entrada__console_8h.html#a8a800238d06462cda1c0dacbe0322f4b", null ],
    [ "pedirPalavra", "_t_p1___kanban_2include_2entrada__console_8h.html#a8be3b21c3df7f724623c9186360f6d2e", null ]
];