var _t_p1___kanban_2include_2iservico__projeto_8h =
[
    [ "IServicoProjeto", "class_i_servico_projeto.html", "class_i_servico_projeto" ]
];