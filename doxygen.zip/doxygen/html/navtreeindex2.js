var NAVTREEINDEX2 =
{
"include_2tamanho_8h_source.html":[1,0,0,32],
"include_2texto_8h.html":[1,0,0,33],
"include_2texto_8h_source.html":[1,0,0,33],
"include_2timestamp_8h.html":[1,0,0,34],
"include_2timestamp_8h_source.html":[1,0,0,34],
"index.html":[],
"main_8cpp.html":[1,0,2],
"main_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4":[1,0,2,0],
"pages.html":[],
"servico__autenticacao_8h_source.html":[1,0,1,0,24],
"servico__cartao_8h_source.html":[1,0,1,0,25],
"servico__pessoa_8h_source.html":[1,0,1,0,26],
"servico__projeto_8h_source.html":[1,0,1,0,27],
"servico__quadro_8h_source.html":[1,0,1,0,28]
};
