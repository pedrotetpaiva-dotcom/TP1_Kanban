var class_container_quadro =
[
    [ "atualizar", "class_container_quadro.html#a18b5254a3a91be727cbc28dc47317cc7", null ],
    [ "incluir", "class_container_quadro.html#ae284360646a5be059b9a916c0badc5d9", null ],
    [ "listarPorProjeto", "class_container_quadro.html#a51dd81dee3048582476595fcbfad16c5", null ],
    [ "pesquisar", "class_container_quadro.html#a1f58375d4712a47b51a52966859ec838", null ],
    [ "pesquisarProjeto", "class_container_quadro.html#ae8128475f857a766349b868756f0346a", null ],
    [ "possuiQuadros", "class_container_quadro.html#ace10b2c50cce733857f63dd91309acae", null ],
    [ "remover", "class_container_quadro.html#a62bcb9e8e055a987403acbc5f563d833", null ]
];