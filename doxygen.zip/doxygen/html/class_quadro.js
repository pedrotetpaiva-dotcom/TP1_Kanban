var class_quadro =
[
    [ "getIdentificador", "class_quadro.html#a422b4527e318b8fbb72d1a98a18dc98c", null ],
    [ "getLimite", "class_quadro.html#a7799b0eea6c85113d94d4f231108c354", null ],
    [ "getNome", "class_quadro.html#a681139cee3671a4934bc5a5a56c8b288", null ],
    [ "setIdentificador", "class_quadro.html#a6cbef16de0378db988fa650249b2b627", null ],
    [ "setLimite", "class_quadro.html#afb9cc6ac383f0bb2171e54b73b52d4f6", null ],
    [ "setNome", "class_quadro.html#a799d4fe709ede0f7b6f1fb3b3d25d27e", null ]
];