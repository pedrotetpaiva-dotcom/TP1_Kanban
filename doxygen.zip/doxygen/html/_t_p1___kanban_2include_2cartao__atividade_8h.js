var _t_p1___kanban_2include_2cartao__atividade_8h =
[
    [ "CartaoAtividade", "class_cartao_atividade.html", "class_cartao_atividade" ]
];