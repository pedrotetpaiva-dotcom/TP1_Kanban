var class_i_servico_quadro =
[
    [ "atualizar", "class_i_servico_quadro.html#affc9b9c6d9ebdd0149d3e452dbcd8ff0", null ],
    [ "atualizar", "class_i_servico_quadro.html#affc9b9c6d9ebdd0149d3e452dbcd8ff0", null ],
    [ "criar", "class_i_servico_quadro.html#a2a5d8b5c4c35175150fe629a343b8ed2", null ],
    [ "criar", "class_i_servico_quadro.html#a2a5d8b5c4c35175150fe629a343b8ed2", null ],
    [ "excluir", "class_i_servico_quadro.html#ac9f2c175f49abe62180bef274551c6cd", null ],
    [ "excluir", "class_i_servico_quadro.html#ac9f2c175f49abe62180bef274551c6cd", null ],
    [ "ler", "class_i_servico_quadro.html#a47b390fc3ff00f31b3cb722d59f6bb8d", null ],
    [ "ler", "class_i_servico_quadro.html#a47b390fc3ff00f31b3cb722d59f6bb8d", null ],
    [ "listar", "class_i_servico_quadro.html#a8649eb29a2e78a92f0b7889c7a7d1f52", null ],
    [ "listar", "class_i_servico_quadro.html#a8649eb29a2e78a92f0b7889c7a7d1f52", null ]
];