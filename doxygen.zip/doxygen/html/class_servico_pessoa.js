var class_servico_pessoa =
[
    [ "atualizar", "class_servico_pessoa.html#ad031fe9cec84ca4f509a5880f415a059", null ],
    [ "criar", "class_servico_pessoa.html#af696eb45cc7192dc48d957ec490a51c3", null ],
    [ "excluir", "class_servico_pessoa.html#a4e3e61dbb78d7ea46b56e31b54c09ffb", null ],
    [ "ler", "class_servico_pessoa.html#aa967c53ee48583781a24a9a26e75afa5", null ],
    [ "listar", "class_servico_pessoa.html#a5de0f2f57990effa6b366bf0e388d2da", null ]
];