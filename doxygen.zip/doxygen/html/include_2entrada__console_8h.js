var include_2entrada__console_8h =
[
    [ "lerLinha", "include_2entrada__console_8h.html#a6d20e8b2df78246cc8bb8204fe35f4b9", null ],
    [ "lerOpcao", "include_2entrada__console_8h.html#adc58f27faa4428f5043e459afb07f1bf", null ],
    [ "lerPalavra", "include_2entrada__console_8h.html#a08fff5e0db87d58e4f0408ffeba8d47d", null ],
    [ "pedirLinha", "include_2entrada__console_8h.html#a8a800238d06462cda1c0dacbe0322f4b", null ],
    [ "pedirPalavra", "include_2entrada__console_8h.html#a8be3b21c3df7f724623c9186360f6d2e", null ]
];