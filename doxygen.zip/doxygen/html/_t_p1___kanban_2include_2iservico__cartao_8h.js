var _t_p1___kanban_2include_2iservico__cartao_8h =
[
    [ "IServicoCartao", "class_i_servico_cartao.html", "class_i_servico_cartao" ]
];