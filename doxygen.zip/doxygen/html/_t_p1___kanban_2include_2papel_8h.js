var _t_p1___kanban_2include_2papel_8h =
[
    [ "Papel", "class_papel.html", "class_papel" ]
];