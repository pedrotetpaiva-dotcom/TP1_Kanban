var _t_p1___kanban_2include_2ctrl__apresentacao__cartao_8h =
[
    [ "CtrlApresentacaoCartao", "class_ctrl_apresentacao_cartao.html", "class_ctrl_apresentacao_cartao" ]
];